/**
 * 
 */


/**
 * @author RUPALI TRIPATHI
 *
 */
public class AccountNotFoundException extends Exception {

}
