package com.hsbc.DAO;


import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.hsbc.model.Employee;

public interface EmployeeDAO {

	
	 void store(Employee e);
	
	
	 Collection<Employee> sortAscId();
	
	 Collection<Employee> sortDescId();
	
	
	
	 Collection<Employee> sortDescSalary();
	
	 Collection<Employee> sortAscSalary();
	 
	  List<Employee> topRankers(List<Employee> l);

	
	//List<Employee> display(); 
	
	
	
}

	
	
	
	
