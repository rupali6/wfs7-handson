package com.hsbc.DAOImpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import com.hsbc.DAO.EmployeeDAO;
import com.hsbc.model.Employee;

public class EmployeeDAOImpl  implements EmployeeDAO {
	
	List<Employee> al=new ArrayList<Employee>();

	@Override
	public void store(Employee e) {
		// TODO Auto-generated method stub
		al.add(e);
	}

	@Override
	public Collection<Employee> sortAscId() {
		// TODO Auto-generated method stub
		Collections.sort(al, (e1,e2) -> e1.getId() - e2.getId());
		return al;
	}

	@Override
	public Collection<Employee> sortDescId() {
		// TODO Auto-generated method stub
		Collections.sort(al, (e1,e2) -> e2.getId() - e1.getId());
		return al;
	}

	@Override
	public Collection<Employee> sortDescSalary() {
		// TODO Auto-generated method stub
		Collections.sort(al, (e1,e2) -> (int)(e1.getSalary() - e2.getSalary()));
		return al;
	}

	@Override
	public Collection<Employee> sortAscSalary() {
		// TODO Auto-generated method stub
		Collections.sort(al, (e1,e2) -> (int)(e2.getSalary() - e1.getSalary()));
		return al;
	}
	
	@Override
	public List<Employee> topRankers(List<Employee> l){
		List<Employee> topRankersList = new ArrayList<Employee>();
		
		int count = 0;
		for(Employee employee:l) {
			topRankersList.add(employee);
			count++;
			if(count == 3)
				break;
		}
		
		return topRankersList;
	}
	

	

}
