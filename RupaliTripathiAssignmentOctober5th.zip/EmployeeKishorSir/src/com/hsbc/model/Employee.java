/**
 * 
 */
package com.hsbc.model;

import java.time.LocalDate;
import java.util.Date;

/**
 * @author RUPALI TRIPATHI
 *
 */
public class Employee {

	/**
	 * @param args
	 */
	String name;
	double salary;
	LocalDate dob;
	int id;
	public Employee(String name, double salary,LocalDate dob, int id) {
		super();
		this.name = name;
		this.salary = salary;
		this.dob = dob;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + ", dob=" + dob + ", id=" + id + "]";
	}
	
	

}
