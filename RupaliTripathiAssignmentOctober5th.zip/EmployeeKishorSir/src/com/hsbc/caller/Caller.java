/**
 * 
 */
package com.hsbc.caller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.hsbc.DAO.EmployeeDAO;
import com.hsbc.DAOImpl.EmployeeDAOImpl;
import com.hsbc.model.Employee;



/**
 * @author RUPALI TRIPATHI
 *
 */
public class Caller {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EmployeeDAO i = new EmployeeDAOImpl();
		Scanner scan=new Scanner(System.in);
		/*Employee e=new Employee("Rupali",50000,LocalDate.of(1998,4,17),451);
		i.store(e);
		Employee e1=new Employee("Anjali",20000,LocalDate.of(1998,4,17),452);
		i.store(e1);
		Employee e2=new Employee("Shefali",20000,LocalDate.of(1998,4,17),453);
		i.store(e2);
		
		i.store(e3);
		Employee e4=new Employee("Aqsa",30000,LocalDate.of(1998,4,17),455);
		i.store(e4);
		;*/
		int choice;boolean exit=false;
		
		/*Collection<Employee> alView=new ArrayList<Employee>();
		alView=i.sortAscId();
		System.out.println(alView);*/
		while(!exit)
        {
		System.out.println("Enter 1. Enter Employee details \n  2. Sort and Display  3. Wanna see top 3?");
		choice=scan.nextInt();
	
		
		switch(choice)
		{
		  case 1: 	  System.out.println("Enter the employee ID:");
			           int id = scan.nextInt();
			  
			          System.out.println("Enter the employee name:");
					String name = scan.next();
			
					System.out.println("Enter the employee salary");
					double salary = scan.nextDouble();
			
					System.out.println("Enter the employee birth data(dd/mm/yyyy):");
					String date = scan.next();
					
					LocalDate localDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("dd/MM/yyyy"));
			
			        Employee e1 = new Employee(name,salary,localDate,id);
			        i.store(e1);
		            break;
		 
		  case 2: System.out.println("Display in ascending order by id");
		          System.out.println(i.sortAscId());
		          System.out.println("");
		          
		          System.out.println("Display in descending order by id");
		          System.out.println(i.sortDescId());
		          System.out.println("");
		          
		          System.out.println("Display in ascending order by salary");
		          System.out.println(i.sortAscSalary());
		          System.out.println("");
		          
		          System.out.println("Display in descending order by salary");
		          System.out.println(i.sortDescSalary());
		          System.out.println("");
		          
		          break;
		          
		  case 3: 
			  //Currently checking only by Id. The same method can be used for as desired/repeatedly
			 Collection<Employee> temp= i.sortAscId();
			// List<Integer> intValuesJava8 = values.stream().collect(Collectors.toList());
			 List<Employee> convertedlist = new ArrayList<Employee>(temp);
			System.out.println( i.topRankers(convertedlist));
			break;
			 
		          
		  case 4: exit=true; 
		          break;
		          
		          
		}
	}
		
		
		

	}

}
